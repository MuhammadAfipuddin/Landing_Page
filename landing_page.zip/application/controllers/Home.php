<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

    public function index(){
        $this->load->model('mahasiswa_model', 'mahasiswa');
        $data['list_mahasiswa'] = $this->mahasiswa->getAll();

        $this->load->model('dosen_model', 'dosen');
        $data['list_dosen'] = $this->dosen->getAll();

        $this->load->model('prodi_model', 'prodi');
        $data['list_prodi'] = $this->prodi->getAll();

        $this->load->view('home/index', $data);
    }
}